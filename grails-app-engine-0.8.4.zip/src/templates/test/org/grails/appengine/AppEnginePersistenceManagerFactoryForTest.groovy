package org.grails.appengine

import javax.jdo.JDOHelper
import javax.persistence.*

import org.datanucleus.store.appengine.jdo.*

/**
 * Entity manager factory for JPA on the app engine.
 * @author juanjo
 */
public final class AppEnginePersistenceManagerFactoryForTests {
    /**
     * Unique instance of the class. It's NEVER null.
     */
    private static final EntityManagerFactory instance
    
    static {
        def pmfClassName = DatastoreJDOPersistenceManagerFactory.class.getName()
        def props = new Properties()
        props['javax.jdo.option.ConnectionURL'] = 'appengine'
        props['javax.jdo.option.NontransactionalRead'] = 'true'
        props['javax.jdo.option.NontransactionalWrite'] = 'true'
        props['javax.jdo.option.RetainValues'] = 'true'
        props['datanucleus.appengine.autoCreateDatastoreTxns'] = 'true'
        props['datanucleus.appengine.autoCreateDatastoreTxns'] = 'true'
        props['javax.jdo.PersistenceManagerFactoryClass'] = pmfClassName
        instance = JDOHelper.getPersistenceManagerFactory(props)
    }

    /**
     * Constructor defined to avoid class clients trying to create instances of
     * this class.
     */
    private AppEnginePersistenceManagerFactoryForTests() {
        throw new IllegalStateException( 'You should not try to instantiate this class.' )
    }

    /**
     * Gets the unique EntityManagerFactory in the JVM.
     *
     * @returns a not <code>null</code> nor duplicated instance
     * EntityManagerFactory for JPA.
     */
    static EntityManagerFactory get() {
        AppEnginePersistenceManagerFactoryForTests.instance
    }
}
