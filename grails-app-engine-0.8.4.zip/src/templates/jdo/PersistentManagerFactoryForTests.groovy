package org.grails.appengine

import javax.jdo.*
import java.util.*

public final class PersistentManagerFactoryForTests {
    private static final PersistenceManagerFactory instance

    static {
        // Create a PMF to do the actual persistence
        def pmfConfig = new Properties()
        pmfConfig['javax.jdo.option.ConnectionURL'] = 'appengine'
        pmfConfig['javax.jdo.option.NontransactionalRead'] = 'true'
        pmfConfig['javax.jdo.option.NontransactionalWrite'] = 'true'
        pmfConfig['javax.jdo.option.RetainValues'] = 'true'
        pmfConfig['datanucleus.appengine.autoCreateDatastoreTxns'] = 'true'
        pmfConfig['datanucleus.appengine.autoCreateDatastoreTxns'] = 'true'
        pmfConfig['javax.jdo.PersistenceManagerFactoryClass'] =  'org.datanucleus.store.appengine.jdo.DatastoreJDOPersistenceManagerFactory'
        pmfConfig['javax.jdo.PersistenceManagerFactoryClass'] = 'org.datanucleus.jdo.JDOPersistenceManagerFactory'
        pmfConfig['datanucleus.persistenceApiName'] = 'JPA' // PMF in "JPA mode"

        if (unitMetaData) {
            if (unitMetaData.getJtaDataSource())
                pmfConfig['datanucleus.ConnectionFactoryName'] = unitMetaData.getJtaDataSource()

            if (unitMetaData.getNonJtaDataSource())
                pmfConfig['datanucleus.ConnectionFactory2Name'] = unitMetaData.getNonJtaDataSource()
                
            if (unitMetaData.getTransactionType())
                pmfConfig['datanucleus.TransactionType'] = unitMetaData.getTransactionType().toString()
                
            if (unitMetaData.getProperties())  {
                // Props for this "persistence-unit"
                props.putAll(unitMetaData.getProperties());
            }
        }
        
        if (overridingProps) {
            // Apply the overriding properties
            props.putAll(overridingProps);
        }
        
        pmfConfig['datanucleus.autoStartMechanism'] = 'None' // Don't allow autostart with JPA
        pmfConfig.remove("datanucleus.PersistenceUnitName"); // Don't specify the persistence-unit

        PersistenceManagerFactory thePMF = JDOHelper.getPersistenceManagerFactory(props);

        if (unitMetaData) {
            // Load up the MetaData implied by this "persistence-unit"
            ObjectManagerFactoryImpl omf = (ObjectManagerFactoryImpl)thePMF;
            omf.getOMFContext().getMetaDataManager().loadPersistenceUnit(unitMetaData, null);
        }

        instance = JDOHelper.getPersistenceManagerFactory( pmfConfig )
    }

    private PersistentManagerFactoryForTests() {
        throw new IllegalArgumentException( 'you should not try to instantiate this class.' )
    }

    public static PersistenceManagerFactory get() {
        PersistentManagerFactoryForTests.instance
    }
}
